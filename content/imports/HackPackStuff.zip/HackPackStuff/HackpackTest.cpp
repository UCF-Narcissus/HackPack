#include <bits/stdc++.h>

using namespace std;
#define eps 1e-6

//Custom structure that defines a vector and all operations that can be performed on the vector
template<typename T>
struct vec{
    //X and Y vector components of type T
    T x, y;

    //define vector using two input variables. If none are entered, set to 0 
    explicit vec(T x=0, T y=0) : x(x), y(y) {}

    //Comparing vectors based off of x first than y
    bool operator<(const vec& v) { return x < v.x || (abs(x - v.x) < eps && y < v.y); }
    bool operator>(const vec& v) { return x > v.x || (abs(x - v.x) < eps && y > v.y); }

    //Vectors are equal iff both the x and y components are equal
    bool operator==(const vec& v) { return abs(x - v.x) < eps && abs(y - v.y) < eps; } 

    //adding or subtracting vectors
    vec operator+(const vec& v) { return vec(x + v.x, y + v.y); }
    vec operator-(const vec& v) { return vec(x - v.x, y - v.y); }

    //scalar multiplication
    vec operator*(const T c) { return vec(x * c, y * c); }

    //dot product
    T dot(const vec& v) { return x * v.x + y * v.y; }

    //cross product given two vectors
    T cross(const vec& v) {return x * o.y - y * o.x; }

    //cross product given three points
    T cross(const vec& v, const vec& u){ return (v-*this).cross(u - *this); }

    //squared distance and distance
    T dist2() { return *this.dot(*this); }
    double dist() { return sqrt(dist2()); }
    double angle() { return atan2(y, x); }

    //unit vector
    vec unit() { return *this * (1.0/dist); }

    //perpindicular vector and normal vector
    vec perp() { return vec(-y, x); }
    vec normal() {return perp().unit(); }

    //vector rotation
    vec rotate(double a) { return vec(x * cos(a) - y * sin(a), x * sin(a) + y * cos(a)); }
};

int main(){

    return 0;
}